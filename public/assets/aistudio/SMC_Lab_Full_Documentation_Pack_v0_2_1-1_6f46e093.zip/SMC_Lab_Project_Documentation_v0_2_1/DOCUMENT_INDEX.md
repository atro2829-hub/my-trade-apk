- [DOCUMENT_MANIFEST_SHA256.txt](DOCUMENT_MANIFEST_SHA256.txt)
- [CHANGELOG_AR.md](CHANGELOG_AR.md)
# فهرس الحزمة

- [README_AR.md](README_AR.md)
- [PROJECT_STATUS.md](PROJECT_STATUS.md)
- [00_PRODUCT_CONSTITUTION.md](docs/00_PRODUCT_CONSTITUTION.md)
- [01_MASTER_PLAN.md](docs/01_MASTER_PLAN.md)
- [02_PRD.md](docs/02_PRD.md)
- [03_JOURNEYS_AND_STATES.md](docs/03_JOURNEYS_AND_STATES.md)
- [04_SMC_RULEBOOK.md](docs/04_SMC_RULEBOOK.md)
- [05_DATA_AND_CHART_SPEC.md](docs/05_DATA_AND_CHART_SPEC.md)
- [06_SIMULATION_ENGINE_SPEC.md](docs/06_SIMULATION_ENGINE_SPEC.md)
- [07_ADAPTIVE_COACH_SPEC.md](docs/07_ADAPTIVE_COACH_SPEC.md)
- [08_ARCHITECTURE_AND_OFFLINE.md](docs/08_ARCHITECTURE_AND_OFFLINE.md)
- [09_UI_UX_SPEC.md](docs/09_UI_UX_SPEC.md)
- [10_QA_TEST_STRATEGY.md](docs/10_QA_TEST_STRATEGY.md)
- [11_AI_AGENT_PROTOCOL.md](docs/11_AI_AGENT_PROTOCOL.md)
- [12_PRIVACY_ADS_SECURITY.md](docs/12_PRIVACY_ADS_SECURITY.md)
- [13_RELEASE_MAINTENANCE.md](docs/13_RELEASE_MAINTENANCE.md)
- [14_RISK_REGISTER.md](docs/14_RISK_REGISTER.md)
- [15_DECISION_LOG.md](docs/15_DECISION_LOG.md)
- [16_BACKLOG_PHASE_GATES.md](docs/16_BACKLOG_PHASE_GATES.md)
- [17_DATA_DICTIONARY.md](docs/17_DATA_DICTIONARY.md)
- [18_TRACEABILITY_MATRIX.csv](docs/18_TRACEABILITY_MATRIX.csv)
- [19_GLOSSARY_AND_REFERENCES.md](docs/19_GLOSSARY_AND_REFERENCES.md)
- [20_AI_TASK_TEMPLATES.md](docs/20_AI_TASK_TEMPLATES.md)

- [SMC_Lab_Complete_Project_Specification_AR.docx](SMC_Lab_Complete_Project_Specification_AR.docx) — وثيقة Word الأساسية للنسخة 0.1.2؛ تُقرأ مع ملحق إغلاق الفجوات 0.2.1 أدناه.
- [SMC_Lab_Gap_Closure_Addendum_AR_v0_2_1.docx](SMC_Lab_Gap_Closure_Addendum_AR_v0_2_1.docx) — نسخة Word لملحقات الفجوات 21–37؛ ملفات Markdown/CSV تظل المصدر القابل للتتبع.
- [SMC_Lab_Content_Pilot_BOS_AR_v0_2_1.docx](SMC_Lab_Content_Pilot_BOS_AR_v0_2_1.docx) — عينة درس BOS وبيانات scenario اصطناعية للمراجعة؛ ليست محتوى إنتاجيًا معتمدًا.

## مستندات إغلاق الفجوات v0.2.1 (مع ملاحق v0.2.0)

- [docs/21_GAP_CLOSURE_PLAN.md](docs/21_GAP_CLOSURE_PLAN.md) — خريطة الفجوات والمالكين والمواعيد.
- [docs/22_DATA_VENDOR_G2_PLAN.md](docs/22_DATA_VENDOR_G2_PLAN.md) — خطة الترخيص وRFI وG2.
- [docs/23_RULEBOOK_PREDICATES_DRAFT.md](docs/23_RULEBOOK_PREDICATES_DRAFT.md) — predicates مرشحة ومعلمات R0.
- [docs/24_CURRICULUM_SCOPE_SEQUENCE.md](docs/24_CURRICULUM_SCOPE_SEQUENCE.md) — 41 درسًا بأهداف ومتطلبات سابقة.
- [docs/25_SCENARIO_AUTHORING_STANDARD.md](docs/25_SCENARIO_AUTHORING_STANDARD.md) — معايير تأليف/مراجعة السيناريو.
- [docs/25A_SCENARIO_CATALOG_96.csv](docs/25A_SCENARIO_CATALOG_96.csv) — كتالوج 96 سيناريو مخططًا، لم يؤلف بعد.
- [docs/26_ADAPTIVE_COACH_ALGORITHM.md](docs/26_ADAPTIVE_COACH_ALGORITHM.md) — عتبات الإتقان واختيار التمرين.
- [docs/27_ANSWER_EVALUATION_ENGINE.md](docs/27_ANSWER_EVALUATION_ENGINE.md) — أنواع الأسئلة والتقييم الجزئي.
- [docs/28_DECISION_RESOLUTIONS.md](docs/28_DECISION_RESOLUTIONS.md) — قرارات تشغيلية مقترحة تحسم الغموض.
- [docs/29_PACK_INFRASTRUCTURE.md](docs/29_PACK_INFRASTRUCTURE.md) — توقيع الحزم وتفعيلها بأمان.
- [docs/30_RESOURCES_TIMELINE_BUSINESS.md](docs/30_RESOURCES_TIMELINE_BUSINESS.md) — الموارد والجدول والتكلفة.
- [docs/31_BACKUP_FEEDBACK_ACCESSIBILITY.md](docs/31_BACKUP_FEEDBACK_ACCESSIBILITY.md) — النسخ الاحتياطي والبلاغات والإتاحة.
- [docs/32_CHART_PERFORMANCE_FALLBACK.md](docs/32_CHART_PERFORMANCE_FALLBACK.md) — اختبار الأداء وخطة البدائل.
- [docs/33_RESEARCH_COMPLIANCE_KPIS.md](docs/33_RESEARCH_COMPLIANCE_KPIS.md) — أبحاث المستخدم والامتثال وKPIs.
- [docs/34_RESEARCHED_VENDOR_NOTES.md](docs/34_RESEARCHED_VENDOR_NOTES.md) — ملاحظات الموردين من البحث المكتبي.

إذا تعارض نص قديم مع ملحقات v0.2.0/v0.2.1، يرجع إلى الوثيقة الأحدث ذات الصلة، لكن المقترحات الموسومة بالموافقة المطلوبة لا تصبح معتمدة حتى توقيع مالك المنتج. لا تعتبر إضافة وثيقة أو صف إلى المصفوفة دليلًا على تنفيذ التطبيق أو اعتماد القاعدة.

- [docs/35_AUDIT_CROSSWALK.csv](docs/35_AUDIT_CROSSWALK.csv) — ربط عناصر المراجعة النقدية بمخرجات الإغلاق والحواجز المتبقية.
- [docs/36_G1_APPROVAL_PACKET_TEMPLATE.md](docs/36_G1_APPROVAL_PACKET_TEMPLATE.md) — نموذج مراجعة واعتماد قواعد SMC.
- [docs/37_G2_VENDOR_DECISION_WORKSHEET.md](docs/37_G2_VENDOR_DECISION_WORKSHEET.md) — نموذج مقارنة وترسية مورد بيانات السوق.

- [docs/38_SAMPLE_LESSON_BOS_AR.md](docs/38_SAMPLE_LESSON_BOS_AR.md) — عينة درس مكتوبة أصلية بأسئلة وتلميحات وتفسير وإرشادات الرسم.
- [docs/39_SAMPLE_SYNTHETIC_SCENARIO_BOS.json](docs/39_SAMPLE_SYNTHETIC_SCENARIO_BOS.json) — سيناريو اصطناعي له decision points وexpected outputs ومسودّة answer key.
