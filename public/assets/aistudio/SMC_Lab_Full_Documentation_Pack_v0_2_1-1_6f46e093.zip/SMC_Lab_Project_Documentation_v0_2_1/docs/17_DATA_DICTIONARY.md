# 17 — قاموس البيانات والمخطط المنطقي

هذا مخطط منطقي. يجب أن يحوله التنفيذ إلى schema وترحيلات SQL فعلية واختبارات migration. لا تضاف حقول أو تغيّر معانيها بصمت.

## Pack
`pack_id` PK، `pack_version`، `schema_version`، `data_kind` (`historical|synthetic|mixed`)، `source_name`, `source_url`, `license_ref`, `license_reviewed_at`, `created_at_utc`, `valid_from_utc`, `valid_to_utc`, `manifest_hash`, `signature_status`, `status` (`staging|active|retired|invalid`), `byte_size`, `minimum_app_version`.

## Instrument
`instrument_id` PK، `symbol`, `base_asset`, `quote_asset`, `tick_size`, `quantity_precision`, `venue_id`, `instrument_type`. لا تستنتج قواعد تنفيذ بورصة غير موجودة في المصدر المصرح.

## Candle
Composite PK: `pack_id`, `instrument_id`, `timeframe`, `open_time_utc_micros`; fields: `close_time_utc_micros`, OHLCV decimal fields, optional quote volume/trade count/source record ID. Index by instrument/timeframe/time.

## Scenario
`scenario_id` + `scenario_version`, pack reference, instrument, dataKind, title key, difficulty, start/end UTC, primary timeframe, learning objectives, prerequisites, `rulebook_version`, `answer_key_version`, `review_status` (`draft|reviewed|approved|retired`).

## DecisionPoint
`decision_point_id`, scenario ID, sequence number, playhead time, task type, required inputs, accepted answer references, Rule IDs, feedback key, reveal condition, `future_data_access_policy=forbidden_until_reveal`.

## UserSession
`session_id`, scenario ID/version, mode (`lesson|challenge|free_chart|simulation`), playhead, speed, session state, started/last saved/ended timestamps.

## UserAnnotation
`annotation_id`, session ID, type (`horizontal_line|trend_line|rectangle|note|label`), coordinates with schema version, color token, created/updated/deleted timestamps.

## DecisionEvent
`event_id`, session/scenario/version/decision point, event sequence, playhead, input payload, result code, rule version, feedback key, attempt index, hint used, unique `idempotency_key`.

## PaperTrade
`trade_id`, session/scenario/version, direction, status, entry mode/price/quantity, stop/target/exit price, exit reason, planned risk/reward, gross/net P&L, fees, slippage, R multiple, execution policy, engine/data/rule versions, opened/closed playhead.

## TradeEvent
`trade_event_id`, trade ID, sequence, event type, playhead, price, payload, unique idempotency key.

## SkillEvidence / SkillProfile
Evidence links each skill to the source event, result, independent scenario key, timestamp, rule version and evidence policy. Profile stores mastery state, attempts, independent scenario count, recent/all-time accuracy, last practice, top error, confidence state, policy version.

## Recommendation
ID, skill, scenario, reason code, policy version, created timestamp, accepted/skipped state, outcome event ID.

## Settings / UpdateManifestRecord
Settings: key/value/update timestamp. Manifest record: version, check timestamp, status, failure code and message key.

## Integrity rules

- FK prevents orphan events.
- Unique idempotency keys prevent duplicate effects.
- Invalid pack cannot be active.
- Approved scenario requires valid pack, answer key and rule versions.
- Historical result retains the versions used; no silent re-evaluation.
- Market timestamps UTC; local time is presentation/logging metadata.
- Each migration has a number and tests data preservation, failure behavior and supported upgrade paths.
