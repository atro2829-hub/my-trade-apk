# 19 — المسرد والمراجع

## 1. المسرد

- **Offline-first:** قراءة/كتابة الوظائف الأساسية من بيانات محلية؛ الشبكة لتحسين المحتوى لا لتعطيل الأساس.
- **Scenario:** حالة تدريب لها بيانات ونقاط قرار ومراجع إجابة وإصدارات.
- **Playhead:** آخر وقت تاريخي وصل إليه المستخدم في replay.
- **Answer key:** مرجع إجابة تمت مراجعته لسيناريو؛ لا يثبت حقيقة مطلقة لكل الشارتات.
- **Rulebook:** القواعد التشغيلية المعتمدة للتطبيق مع إصدارات.
- **Paper trade:** صفقة افتراضية لا تنفذ في سوق حقيقي.
- **R multiple:** نتيجة الصفقة مقسومة على المخاطرة المخططة حسب تعريف المحرك.
- **Look-ahead/data leakage:** استخدام بيانات مستقبلية غير متاحة عند اتخاذ القرار.
- **Backtest overfitting:** تعديل الاستراتيجية على بيانات اختبار حتى تبدو جيدة ولا تعمم.
- **Vertical slice:** رحلة صغيرة كاملة عبر واجهة ومنطق وبيانات واختبار.
- **Traceability:** ربط المتطلب بالتنفيذ والاختبار والدليل.
- **Atomic activation:** إما تفعيل pack كاملة بعد التحقق أو عدم تفعيلها.

## 2. المرجع التعليمي المقدم

الملف المرفق `smart money concept.pdf` بعنوان ظاهر Adamas 0.1 (70 صفحة) يغطي هيكل السوق، BOS/CHOCH، IDM/VIDM/IDMT، القمم والقيعان الحقيقية، imbalance، order flow، OB والأنواع المرتبطة، السيولة، IFC، Fibonacci، BCD، Flip Zone، ترابط الفريمات، الدخول، سيكولوجية التداول وإدارة المخاطر. يستخدمه المشروع لفهم الموضوعات، مع محتوى ورسوم أصلية ومراجعة شروط التشغيل قبل الاستخدام التجاري.

## 3. المراجع الرسمية/العلمية — تاريخ الفحص 29 أكتوبر 2026

1. Flutter, Guide to app architecture: https://docs.flutter.dev/app-architecture/guide — فصل view/view model/repository/service.
2. Android Developers, Build an offline-first app: https://developer.android.com/topic/architecture/data-layer/offline-first — البيانات المحلية أولًا والعمل دون اتصال.
3. Google Mobile Ads Flutter quick start: https://developers.google.com/admob/flutter/quick-start — إعداد SDK؛ راجع المتطلبات السارية عند البناء.
4. AdMob, Disallowed interstitial implementations: https://support.google.com/admob/answer/6201362?hl=en — تجنب الإعلان المزعج أو المعطل للتفاعل.
5. Google Play Data safety / user data: https://support.google.com/googleplay/android-developer/answer/10144311?hl=en — راجع الإفصاحات مع SDKs عند الإصدار.
6. Binance Vision Dataset Terms (مراجعة 29 أكتوبر 2026; النص المعروض يذكر آخر تحديث 26 أغسطس 2026): https://github.com/binance/binance-public-data/blob/master/TERMS_AND_CONDITIONS.md — يستبعد الترخيص التجاري من الاتفاقية العامة ويطلب اتفاقية مؤسسية مكتوبة للاستخدام التجاري. لا يُستخدم مصدر Binance Vision في منتج تجاري دون إذن منفصل مكتوب ومراجَع.
7. Dunlosky et al. (2013), Improving Students’ Learning With Effective Learning Techniques: https://doi.org/10.1177/1529100612453266 — مراجعة تقنيات مثل الاختبار الذاتي والممارسة الموزعة.
8. Roediger & Karpicke (2006), Test-Enhanced Learning: https://doi.org/10.1111/j.1467-9280.2006.01693.x — بحث أثر الاختبار على الاحتفاظ طويل الأجل.
9. Hattie & Timperley (2007), The Power of Feedback: https://doi.org/10.3102/003465430298487 — طبيعة feedback وتفاوت أثره حسب الطريقة.
10. Bailey et al. (2017), The Probability of Backtest Overfitting: https://doi.org/10.21314/jcf.2016.322 — خطر فرط التوافق في الاختبارات التاريخية.

## 4. حدود الاستناد

لا تعني هذه المراجع أن كل قاعدة SMC مثبتة علميًا أو أن حركة السعر تكشف نوايا المؤسسات. أبحاث التعلم توجه تصميم التدريب لكنها لا تثبت ربحية استراتيجية. تراجع الروابط والسياسات الرسمية المتغيرة قبل كل إصدار. لو تغيرت شروط مزود البيانات، لا يعتمد التغيير تلقائيًا؛ يُحدّث سجل الحقوق والقرار G2.
