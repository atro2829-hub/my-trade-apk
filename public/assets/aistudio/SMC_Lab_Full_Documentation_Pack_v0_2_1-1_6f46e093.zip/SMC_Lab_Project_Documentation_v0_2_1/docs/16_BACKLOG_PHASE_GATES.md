> **إشعار توثيقي v0.2.0:** راجع `21_GAP_CLOSURE_PLAN.md` لمالكي الفجوات ومواعيدها النسبية، و`30_RESOURCES_TIMELINE_BUSINESS.md` للتقدير المرجعي.

# 16 — قائمة العمل والمراحل وبوابات القبول

## قواعد تقسيم المهام
- كل مهمة صغيرة بقدر يسمح بمراجعة diff واختبارها بصورة مستقلة.
- كل مهمة مرتبطة بمعرفات متطلبات، واعتماديات، وملفات مسموح تعديلها، ومعايير قبول واختبارات ودليل.
- لا تعمل مهمتان متزامنتان على schema أو محرك واحد دون تنسيق branch واضح.
- الترتيب حسب الاعتمادية والمخاطر لا سهولة الواجهة.

## Phase 0 — Project Operating System
**المهام:** المستودع المستمر، Git branches، فحص البيئة الفعلية، تثبيت Flutter/SDK/Gradle/JDK، الوثائق، lint/analysis/tests، CI، قوالب Issue/PR.  
**المخرجات:** build skeleton وCI والـ lockfiles وفهرس المستندات.  
**Exit:** بناء واختبار أساسيان ينجحان في بيئة موثقة.

## Phase 1 — Domain/Data proof
**المهام:** نماذج Candle/Pack/Scenario/Playhead/Trade؛ SQLite schema؛ manifest؛ fixtures؛ spike للشارت؛ playhead؛ pack محلي صغير.  
**Exit:** عرض صحيح للشموع دون نت، توقيت سليم، عدم تسرب المستقبل، وأداء مقبول على جهاز مرجعي.

## Phase 2 — Vertical slice كامل
**المهام:** تحدٍ واحد وanswer key، قرار مستخدم، صفقة افتراضية، replay، تقرير، حفظ/استعادة، وتوصية coach بسيطة.  
**Exit:** J-004/J-005 تعملان offline مع اختبارات حساب وحفظ ناجحة.

## Phase 3 — اعتماد Rulebook الأساسي
**المهام:** مراجعة MST/HH-HL-LH-LL/BOS/CHOCH/liquidity/IDM/IMB/OB؛ fixtures وحالات سلبية وتفسيرات.  
**Exit:** G1؛ لا grading إنتاجي بقواعد ما زالت DOMAIN_REVIEW.

## Phase 4 — الشارت والفريمات
**المهام:** أدوات الرسم، مزامنة الفريم، annotations، وسوم السيناريو، RTL/accessibility، benchmark.  
**Exit:** chart acceptance على أجهزة مرجعية واختبارات playhead/RTL pass.

## Phase 5 — محرك المحاكاة والدفتر
**المهام:** حالات الصفقة، sizing، سياسة stop/target، الرسوم/الانزلاق الافتراضية، حد يومي، journal، تقارير.  
**Exit:** unit/contract/integration tests pass وحتمية replay مثبتة.

## Phase 6 — المدرب والمنهج
**المهام:** skill model، تصنيف الخطأ، جدولة التكرار، اختيار سيناريو متكيف، الدروس والاختبارات.  
**Exit:** اختبارات سياسة coach pass، ولا مبالغة بالإتقان عند قلة العينة.

## Phase 7 — نشر packs والتحديث
**المهام:** فحص مصدر البيانات وحقوقه، normalization pipeline، manifest/hash/signature، staging، atomic activation، rollback، Wi-Fi-only.  
**Exit:** fault injection pass وG2 مغلقة للحزمة التاريخية الحقيقية.

## Phase 8 — AdMob والامتثال
**المهام:** adapter معزول، banner محدود، fallback، مراجعة خصوصية/موافقة وسياسات.  
**Exit:** لا إعلان في التدفقات النشطة؛ فشل SDK معزول؛ مراجعة حديثة موثقة.

## Phase 9 — تقوية عامة
**المهام:** offline acceptance، مساحة منخفضة، process death، migrations، dependency/license review، أداء وRTL/LTR وTalkBack.  
**Exit:** صفر P0/P1 مفتوحة وجميع الرحلات المطلوبة pass.

## Phase 10 — Release Candidate
**المهام:** APK/AAB، توقيع آمن، بيانات المتجر، الإفصاح والخصوصية وحقوق المحتوى، QA report، rollback plan.  
**Exit:** G8/G9 و100% من متطلبات P0/P1 موثقة بالأدلة.

## قالب حجم المهمة
`Task ID; purpose; requirements; dependencies; allowed files; acceptance criteria; tests; artifacts; risks; rollback; documentation updates`.

## ترتيب الاعتماديات
`Project OS → Data/Domain proof → Vertical slice → Rulebook/Chart → Simulation → Coach/Curriculum → Update/Ads → Hardening → Release`.

يمكن بناء adapter والاختبارات باستخدام بيانات synthetic قبل G2، لكن لا يجوز إدخال بيانات تاريخية غير مرخصة إلى المنتج أو إعلان اجتياز بوابة الحقوق.
