# 23 — predicates تشغيلية مرشحة لقواعد SMC (مراجعة بشرية إلزامية)

**الحالة:** `DRAFT — DOMAIN_REVIEW_REQUIRED`. هذه قواعد تشغيلية مرشحة وليست قواعد SMC عالمية أو معتمدة. يجب الفصل بين ما يذكره كتاب Adamas 0.1 وبين تفاصيل أضافها المشروع لإزالة الغموض. لا تدخل أي قاعدة التقييم الإنتاجي قبل توقيع مالك المنهج ومراجع مستقل.

## 1. مخطط القاعدة

لكل قاعدة: `ruleId`, `ruleVersion`, `status`, `sourceBasis`, `operationalization`, `inputs`, `parameters`, `predicate`, `invalidators`, `ambiguityPolicy`, `feedbackKeys`, `goldenCases`, `reviewSignatures`, `effectiveFrom`.

## 2. قواعد عامة

- الأسعار تستخدم `priceTick` ودقة الرمز؛ لا تستخدم مساواة floating-point.
- لا ترى القاعدة إلا `visibleDataThrough`. أي تأكيد يحتاج شموعًا لاحقة لا يظهر حتى إغلاقها.
- يحدد السيناريو المستوى المرجعي قبل نقطة القرار؛ يمنع الاختيار بأثر رجعي بناء على المستقبل.
- لكل قاعدة ناتج `PASS`, `FAIL`, أو `UNASSESSABLE`; لا يحوّل نقص البيانات إلى إجابة خاطئة.
- قيم R0 التالية فرضيات تشغيلية تحتاج اعتمادًا؛ لا تنسب إلى نص الكتاب حرفيًا.

## 3. معلمات مرشح R0

| Parameter | قيمة R0 المقترحة | الوصف | الحالة |
|---|---:|---|---|
| `swingLeftBars` | 2 | شموع يسار pivot | REVIEW |
| `swingRightBars` | 2 | شموع يمين يلزم إغلاقها قبل التأكيد | REVIEW؛ لا يعرض pivot قبلها |
| `minBreakDistanceTicks` | 1 tick | هامش تجاوز المستوى | REVIEW |
| `equalLevelTolerance` | `max(2 ticks, 0.05 × ATR14)` | تقارب مستويات متساوية | REVIEW |
| `imbalanceLookbackBars` | 3 شموع | نموذج فجوة 3-candle | REVIEW |
| `displacementBodyToATR` | body ≥ 0.8 × ATR14 | مرشح اندفاع | REVIEW |
| `OB confirmationWindow` | 5 شموع مغلقة | حد زمني لتأكيد الحركة/الهيكل | REVIEW |
| `OB maximumValidTouches` | لمستان؛ الثالثة غير صالحة | مستمد من الكتاب؛ تعريف اللمسة يحتاج مراجعة | REVIEW |
| `wickCloseConfirmationWindow` | 3 شموع لاحقة | حد تشغيلي مقترح لحالة الذيل ثم الإغلاق | REVIEW |
| `zoneIoU fullCredit` | ≥0.80 | تقييم منطقة مرسومة | REVIEW |
| `pointTolerance` | `max(2 ticks, 0.05 × ATR14)` | تقييم نقطة سعرية | REVIEW |

تحسب ATR14 من شموع مغلقة متاحة عند القرار فقط. إذا غابت 14 شمعة أو tick size، تستخدم حالة `UNASSESSABLE` أو قيمة ثابتة موثقة في السيناريو.

## 4. تعريفات قابلة للاختبار — مرشحة

### `SMC.SWING.PIVOT_CONFIRMED`
الشمعة i مرشحة swing high إذا كان `high[i]` أكبر من highs للشموع `i-2,i-1,i+1,i+2` وفق قاعدة التعادل المعتمدة؛ swing low متناظرة. لا تعرض confirmed قبل إغلاق i+2. هذا proxy حسابي وليس تعريفًا حرفيًا في الكتاب.

### `SMC.MST.TREND_STATE` و`SMC.SWING.HH_HL_LH_LL`
تستخدم swings confirmed فقط. تقارن HH/HL بآخر swing من النوع نفسه ضمن الهيكل المحدد في السيناريو. مرشح الاتجاه الصاعد يتطلب زوجين متتاليين من HH/HL (`trendMinConfirmedPairs=2` مبدئيًا)، والهابط متناظر. غير ذلك `RANGE_OR_UNCLEAR` بدل إجبار الاتجاه. المعلمة تحتاج اعتمادًا.

### `SMC.BOS.CLOSE_BREAK`
صاعد: `close > referenceSwingHigh + minBreakDistanceTicks × tickSize`. هابط: `close < referenceSwingLow - minBreakDistanceTicks × tickSize`. يجب أن يكون swing مرجعيًا ومتاحًا قبل شمعة القرار. تجاوز الذيل وحده لا يكفي. فتح شمعة عبر gap فوق المستوى يسجل نوعًا منفصلًا `OPEN_GAP_BREAK` للمراجعة.

### `SMC.BOS.WICK_SWEEP`
سحب صاعد: `high > level + tolerance` و`close <= level + tolerance`. سحب هابط: `low < level - tolerance` و`close >= level - tolerance`. هذا وصف علاقة سعرية ولا يثبت وجود أوامر فعلية أو نية مؤسسة.

### `SMC.BOS.WICK_THEN_CLOSE`
إذا سُحب المستوى بالذيل ثم أغلقت شمعة لاحقة وراء المستوى الأصلي، يسجل التأكيد فقط بعد إغلاق الشمعة اللاحقة. نافذة 3 شموع حل تشغيلي مقترح، يحتاج مراجعة.

### `SMC.CHOCH.STRUCTURE_CHANGE`
يحدد السيناريو مسبقًا `protectedSwingId` والسياق الحالي. تغير صاعد إلى هابط مرشح عند إغلاق مؤهل تحت protected swing low؛ والعكس فوق protected swing high. الذيل وحده sweep، لا CHOCH مؤكد. يجب ربط real swing بتسلسل IDM/structure المعتمد، لا بكسر مفرد فقط.

### `SMC.LIQ.EQUAL_LEVELS`
مجموعة قمم/قيعان مختلفة الزمن ضمن `max(2 ticks, 0.05×ATR14)`. تحفظ كـ `levelCluster` لا خط واحد مختار بصمت. التفاوت قابل للمعايرة ويحتاج اعتمادًا.

### `SMC.LIQ.SWEEP`
يتطلب تجاوز مستوى مرجعي بالهامش المقرر؛ تحفظ أعلى/أدنى نقطة والإغلاق والوقت. النتيجة لا تقول إن التطبيق رأى دفتر الأوامر.

### `SMC.IDM.VALIDATION`, `SMC.IDM.VIDM_IDMT`
يجب أن يحدد السيناريو `candidatePullbackStart`, `candidatePullbackEnd`, `lastTrueSwing`, `internalCandidateId` وقاعدة الحالة التي يجري اختبارها. لا يكفي وجود تصحيح لقبول VIDM. إذا لم يحدد المرجع التسلسلي المطلوب، تكون النتيجة `UNASSESSABLE`.

### `SMC.SWING.REAL_INVALID`
قاع حقيقي مرشح في الاتجاه الصاعد إذا تحقق تسلسل سحب الحافز ثم كسر القمة التي عينها السيناريو؛ القمة الحقيقية متناظرة في الاتجاه الهابط وفق تعريف الكتاب. لا يصنف swing بأنه غير حقيقي قبل انقضاء نافذة التحقق؛ قد تكون الحالة `PENDING`.

### `SMC.IMB.DETECTION`
فجوة 3-candle صاعدة مرشحة إذا `low[i] > high[i-2]`؛ هابطة إذا `high[i] < low[i-2]`، من الشموع المغلقة فقط. حدود المنطقة للصاعدة `[high[i-2], low[i]]` وللهابطة `[high[i], low[i-2]]`. لا تعني القاعدة أن السعر سيملأ المنطقة.

### `SMC.OB.VALIDATION`
مرشح OB صاعد: آخر شمعة هابطة ضمن lookback قبل حركة صاعدة مؤهلة؛ يجب توفر مستوى سيولة/حافز محدد تم سحبه، وimbalance أو displacement ضمن النافذة، وتحقق كسر البنية المرجعية خلال 5 شموع مغلقة. OB الهابط متناظر. النطاق الافتراضي المرشح full candle `[low,high]`؛ body-only قاعدة أخرى صريحة. تحفظ `zoneId`, `formedAt`, `confirmationAt`, `touchCount`, `invalidatedAt`.

### `SMC.OB.TOUCH_LIFECYCLE`
تتكون `touchEpisode` من شموع متتالية تتقاطع مع المنطقة ولا تحسب كل شمعة زيارة جديدة. لا تزيد `touchCount` إلا بعد خروج السعر من النطاق ثم عودته. الثالثة غير صالحة وفق الكتاب، لكن تعريف episode/tolerance يحتاج توقيع المراجع.

### `SMC.BB.VALIDATION`, `SMC.MB.VALIDATION`, `SMC.RJB.VALIDATION`
لكل قاعدة fixtures منفصلة؛ لا تُستنتج predicates من الاسم فقط. BB يتطلب سياق order block وكسر/تغير هيكل وفق السيناريو؛ MB يختبر الفشل/عدم تحقق المرجع حسب الكتاب ولا يدمج مع BB؛ RJB يتطلب تحديد الشمعتين والافتتاح المتساوي والتسامح وحدود الذيول بعد مراجعة المراجع.

### `SMC.IFC.VALIDATION`, `SMC.BCD.VALIDATION`
IFC يحتاج مستوى سيولة مسحوبًا بالذيل وتوقيتًا لا يظهر الإغلاق التأكيدي قبل وقته. BCD يحتاج قواعد رقمية معتمدة لمعنى الابتلاع/حجم الشمعة/الذيول والاتجاه؛ لا يُستنتج الحجم المؤسسي من OHLC وحده، وإذا لم تتوفر بيانات حجم فلا يُخترع حجم.

### `SMC.FIBO.INTEREST_ZONE`, `SMC.FZ.VALIDATION`
مستويات FIBO المرشحة من الكتاب: 0.70/0.75/0.80/0.85 مع اتجاه رسم يحدده السيناريو. لا تستخدمها إن كانت قاعدة المنهج تشترط وجود OB صالح. FZ تتطلب التسلسل المرجعي للتفاعل/كسر المنطقة/تغير الهيكل والحافز، لا مجرد كسر منفرد.

### `SMC.MTF.CONFLUENCE`
لا تستخدم HTF candle قبل إغلاقها. يحدد السيناريو الأطر وأدوارها وتوقيت توفر كل إغلاق. اختلاف الفريمات قد ينتج `WAIT` أو `NO_TRADE` وليس بالضرورة FAIL.

### `SMC.ENTRY.TREND_CONTINUATION` و`SMC.ENTRY.STRUCTURE_CHANGE`
يعتمد التقييم على شروط استراتيجية السيناريو: اتجاه/هيكل، سحب الحافز، POI، تأكيد LTF عند اشتراطه، invalidation، الوقف/الهدف، وحد الخطر. لا تدخل نتيجة الربح في جودة التحليل.

## 5. الحالات الذهبية المطلوبة

لكل قاعدة P0: حالة PASS، وnear-miss يفشل شرطًا واحدًا، وحالة حدودية حول tolerance، وحالة بيانات ناقصة تنتج UNASSESSABLE، وحالة زمنية تمنع lookahead، وإجابات بديلة معتمدة عندما تكون ممكنة. الكاتب لا يكون المراجع النهائي الوحيد.

## 6. إغلاق G1

G1 لا يغلق حتى تكون لكل قاعدة P0 معلمات معتمدة؛ كل تفصيل إضافي عن الكتاب موسوم كقرار تشغيلي؛ fixtures والنتائج المتوقعة موقعة؛ SMC Method Owner ومراجع مستقل يوقعان؛ وتنجح اختبارات regression وlookahead.

## 7. حدود الادعاء

هذا المسرد إزالة غموض هندسية مقترحة، ولا يصادق على ربحية استراتيجية أو يثبت نوايا المؤسسات. تغيير أي threshold يتطلب إصدار rulebook جديدًا واختبارات جديدة، ولا يعيد حساب نتائج المستخدم السابقة بصمت.
