# 29 — بنية استضافة وتوزيع حزم البيانات

## 1. النطاق

لا يحتاج v1 إلى حساب مستخدم أو قاعدة سحابية لتشغيل التعليم. يحتاج قناة ثابتة لنشر manifest وحزم محتوى/بيانات مرخصة. لا تُرسل سجلات المستخدم أو صفقاته إلى هذا المسار.

## 2. البنية المرجعية

`Content Authoring Repo → Validation/Build Pipeline → Signed Manifest + Immutable Pack Objects → Object Storage → CDN/HTTPS → Android Downloader → Staging → Verify → Atomic Activate → Local Pack Reader`.

مكونات مقترحة: object storage مع إصدار؛ CDN/HTTPS وETag/Range عند الحاجة؛ CI يتحقق من schema وترتيب timestamps وصحة OHLC والتراخيص؛ مسار توقيع منفصل؛ ومفتاح خاص داخل KMS/secret store لا في مستودع الكود.

الـ manifest يحتوي: `keyId`, `manifestVersion`, `packId`, `packVersion`, `schemaVersion`, `minAppVersion`, `sizeBytes`, `sha256`, `downloadUrl`, `dataKind`, `sourceId`, `licenseId`, `attribution`, `createdAt`, `retirePolicy`.

## 3. التوقيع

- يوقّع canonical manifest باستخدام Ed25519 أو scheme معتمد بعد مراجعة المكتبة.
- المفتاح العام فقط داخل التطبيق؛ المفتاح الخاص في KMS/secret store بصلاحيات محدودة وسجل تدقيق.
- لكل مفتاح `keyId`؛ يدعم التطبيق current/next key خلال التدوير. لا يلغي تدوير المفتاح manifests القديمة تلقائيًا.
- SHA-256 يثبت سلامة النقل لا صحة المحتوى أو الحقوق؛ التحقق التحريري/الترخيصي يحدث قبل التوقيع.
- لا تخزن API secrets في APK. الحزم المحلية ليست محمية من الاستخراج بنسبة 100%؛ التشفير يصعّب الاستخراج ولا يحل الترخيص.

## 4. التنزيل والتفعيل

1. تنزيل manifest والتحقق من التوقيع والإصدار.
2. عرض الاسم والوصف والحجم والمتطلبات.
3. كتابة الحزمة في `.part` أو staging منفصل واستكمالها إن أمكن.
4. التحقق من الحجم وSHA-256 وschema وترابط الملفات والتوقيت.
5. التحقق من `licenseId` وسجل المصدر في خط النشر قبل التوقيع.
6. فحص مساحة التخزين.
7. تفعيل ذري بتبديل active pointer فقط بعد نجاح جميع الفحوصات.
8. الاحتفاظ بآخر pack صالح؛ إذا فشل migration/verification يبقى القديم فعالًا.
9. حذف staging الفاشل فقط، لا سجل التقدم ولا آخر pack صالح.

## 5. الاحتفاظ والإصدارات

كل pack immutable؛ الإصلاح يخلق نسخة جديدة. لا تُغيّر bytes لإصدار قائم. يحتفظ الخادم بالنسخ المدعومة وفق سياسة يتم تحديدها بعد حساب التكلفة. محليًا يحتفظ التطبيق بالنسخة النشطة والسابقة وأي نسخة تشير إليها جلسة/تقرير محفوظ. `retireAfter` لا يحذف محليًا تلقائيًا دون مراجعة شروط العقد وإفصاح المستخدم.

## 6. التطبيق الأقدم

إذا كان `minAppVersion` أعلى من الحالي، يمنع تنزيل/تفعيل هذا pack ويعرض سببًا ورابط المتجر عند وجود اتصال. تبقى الحزم المتوافقة متاحة. تحديث APK/AAB عبر Google Play، لا self-update في v1.

## 7. تكلفة التشغيل

لا يلزم backend stateful للمستخدمين؛ الكلفة الأساسية تخزين ونقل ومراقبة/دومين/توقيع. `Monthly_Egress = Σ(packSize × successfulDownloads)`. تُقاس أحجام packs في prototype وتُقارن سيناريوهات 1k/10k/100k تنزيل قبل اختيار الاستضافة.

## 8. اختبارات الأعطال

- manifest معدّل أو keyId غير معروف: رفض.
- hash خاطئ: رفض وحذف staging فقط.
- تنزيل منقطع/مساحة منخفضة: توقف آمن دون تفعيل ناقص أو فقد progress.
- schema أو minAppVersion غير متوافق: رفض pack الجديد مع إبقاء القديم.
- فشل migration: rollback.
- pack مرتبط بجلسة محفوظة: منع garbage collection.
