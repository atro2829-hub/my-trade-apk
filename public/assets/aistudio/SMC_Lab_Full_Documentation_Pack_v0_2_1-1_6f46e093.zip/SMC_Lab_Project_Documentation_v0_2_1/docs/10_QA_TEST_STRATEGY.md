# 10 — خطة الجودة والاختبارات

## 1. القاعدة

كل اختبار يرتبط بمتطلب ثابت ويجب أن يسجل البيئة والإصدار والخطوات وexpected/actual والنتيجة. لا يكفي قول «جربت وكل شيء يعمل» دون دليل قابل للتكرار.

## 2. طبقات الاختبار

### Unit
حساب الأسعار وP&L وR، قواعد SMC الحتمية، playhead، تصنيف الخطأ وسياسة التدريب، parsing manifest والتحقق من hash، حالات الصفقة وidempotency.

### Contract
Chart repository لا يعيد بيانات مستقبلية في challenge؛ answer key متوافقة مع rule version؛ simulator يقرأ مصدر بيانات مقيدًا؛ updater لا يفعل pack غير موثوق؛ coach يعيد recommendation مع reason code.

### Integration
SQLite/migrations، تنزيل pack إلى staging والتحقق والتفعيل والrollback، حفظ واستعادة جلسة، تحديث journal/skill profile داخل معاملات سليمة.

### UI/Widget
validation وحالات empty/error، التنقل، أدوات الرسم والتعديل والحذف، RTL/LTR، التفاعل مع app lifecycle.

### End-to-end
- رحلة كاملة offline من فتح المحتوى إلى نتيجة محفوظة.
- تحديث pack عبر الإنترنت ثم تشغيله offline.
- فشل تحديث يبقي النسخة السابقة فعالة.
- تحدٍ يمنع تسرب المستقبل.
- صفقة لا تتكرر بعد إعادة تشغيل التطبيق.

### Manual/device
جهاز Android منخفض الموارد وجهاز متوسط/حديث على الأقل؛ وضع الطيران، شبكة متقطعة، مساحة منخفضة، تدوير الشاشة، background/resume، نص كبير، RTL، واختبار أداء الشارت.

### Benchmark acceptance protocol
- توثيق موديل الجهاز المرجعي، Android build، refresh rate، نسخة Release، commit، pack/fixture، وطريقة جمع القياس.
- استخدام 500 شمعة ظاهرة/متاحة في fixture موثق؛ تكرار تحميل الشارت 30 مرة وحساب p95 لزمن العرض الأول. الهدف ≤1.5 ثانية.
- تشغيل pan/zoom لمدة 60 ثانية على جهاز 60Hz مع frame timing trace؛ هدف p95 ≤16.7ms.
- ترك الشارت في جلسة تفاعل 20 دقيقة مع التنقل بين الإيماءات؛ صفر crash/OOM.
- إرفاق trace وملخص القياس؛ لا يعد الأداء PASS دون دليل. أي اقتراح لتغيير الحدود يمر عبر Change Request ويعتمد قبل تعديل المصفوفة.

## 3. Fixtures لازمة

`fixture_data_valid`, `fixture_data_duplicate`, `fixture_data_unit_mismatch`, `fixture_data_gap`, `fixture_smc_bos_close`, `fixture_smc_wick_sweep`, `fixture_smc_choch`, `fixture_sim_same_bar_stop_target`, `fixture_sim_gap_open`, `fixture_pack_bad_hash`, `fixture_pack_wrong_schema`, `fixture_coach_repeated_error`, `fixture_coach_small_sample`.

كل fixture يتضمن expected output ثابتًا. لا يعدل المتوقع لمجاراة الكود دون Change Request ومراجعة السبب.

## 4. CI

على كل PR: formatting check، static analysis بأخطاء صفر، unit/contract tests، tests المتأثرة، فحص التبعيات والأسرار، وبناء اختبار.

على Release Candidate: الاختبارات الحرجة كاملة، تحليل Flutter نظيف، بناء Release APK وAAB عند النشر عبر Play، Offline Acceptance على جهاز فعلي، مراجعة تراخيص packs وprivacy/ads/Data safety، اختبار migrations/restore، وتقرير QA يربط الإصدار والـ commit والـ pack hashes.

## 5. درجات العيب

- **P0 Critical:** فقد/فساد بيانات، تسرب مستقبل للتقييم، حسابات واسعة خاطئة، تداول حقيقي غير مصرح، تعطل كامل.
- **P1 High:** وظيفة أساسية لا تعمل، قاعدة أساسية خاطئة، المحاكاة غير حتمية، فشل core offline.
- **P2 Medium:** خلل ثانوي مع workaround.
- **P3 Low:** تحسين تجميلي.

لا إطلاق مع P0/P1 مفتوح. قبول P2/P3 يحتاج مالكًا وسببًا وworkaround.

## 6. انضباط التقييم التاريخي

تُفصل مجموعات التطوير والاختبار؛ لا تختبر استراتيجية فقط على الحالات التي صممت عليها. توثق كل النسخ البديلة التي جرى تجربتها. إذا استخدمت مجموعة holdout لتعديل القاعدة، لم تعد مستقلة ويجب إعداد مجموعة جديدة. تعرض التقارير حجم العينة والأصل والفريم والقيود ولا تعمم الأداء على المستقبل.

## 7. Offline Acceptance Gate

1. تثبيت QA/Release build مع pack أساسية.
2. تفعيل وضع الطيران وإغلاق التطبيق بالكامل.
3. فتح درس وتمرين وشارت وتغيير فريم متاح وحفظ رسم.
4. فتح صفقة افتراضية وتشغيلها إلى خروج ثم حفظ التقرير.
5. إغلاق التطبيق وإعادة فتحه واستعادة السجل.
6. فتح تقرير المهارات والحصول على اقتراح تدريب.
7. التأكد من عدم وجود شاشة تنتظر شبكة/إعلان.

أي فشل يحجب الإطلاق حسب شدته.

## 8. تقرير الاختبار

commit hash، إصدار التطبيق والحزمة والقواعد، جهاز/Android version، خطوات، expected/actual، pass/fail/not run، العيوب، logs وصور عند الحاجة. لا تستخدم معلومات مستخدم حقيقية في fixtures.
