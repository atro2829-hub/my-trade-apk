# 08 — المعمارية والتخزين المحلي والعمل دون اتصال

## 1. قرارات المعمارية

- تطبيق Android حقيقي بـ Flutter.
- تنظيم feature-first مع فصل UI / application use cases / domain / data.
- نمط MVVM لواجهات المستخدم مع طبقة domain مستقلة للقواعد والمحاكاة والتقييم.
- SQLite مصدر الحقيقة للبيانات المنظمة والتقدم؛ ملفات منفصلة للحزم الكبيرة مع metadata وفهارس.
- Drift للوصول إلى SQLite كخيار تنفيذ baseline بعد اختبار توافق مبكر؛ لا يستبدل دون قرار موثق إذا فشل spike.
- رسم الشموع عبر Canvas/CustomPainter مخصص في v1 للتحكم في الأداء والإيماءات ومنع WebView.
- Riverpod لإدارة الحالة والاعتماديات؛ تثبت الإصدارات الفعلية في lockfile.
- لا backend لحسابات المستخدم أو سجله. خدمة تحديث packs تستضيف manifests وحزمًا ولا تخزن profile المستخدم.

## 2. طبقات المسؤولية

### Presentation
Views وViewModels تعرض UI state وتستقبل أوامر المستخدم. لا تضع حسابات الأسعار أو P&L أو قواعد SMC داخل widgets.

### Application / Use cases
أوامر مثل `StartScenario`, `SubmitDecision`, `AdvancePlayback`, `OpenPaperTrade`, `ClosePaperTrade`, `BuildReport`, `CheckForPacks`, `ActivatePack`. تتحقق من القواعد وتنسق المكونات دون كشف بيانات مستقبلية.

### Domain
Candle, Scenario, DecisionPoint, Rule, PaperTrade, TradeEvent, SkillEvidence, PackManifest؛ مع Rule Engine وPlayback Engine وSimulator وAssessment Policy.

### Data
Repositories محلية، قاعدة SQL، file-pack reader، manifest client، downloader، hash/signature verifier، migrations وsettings.

### Platform adapters
AdMob، الاتصال، مشاركة/تصدير الملفات، Android lifecycle. لكل adapter فشل معزول وfallback.

## 3. بنية ملفات إرشادية

```text
lib/app/
lib/core/errors/ ids/ time/ storage/
lib/features/onboarding/ curriculum/ chart/ scenarios/
lib/features/smc_rules/ playback/ simulation/ journal/
lib/features/assessment/ coach/ pack_updates/ settings/ ads/
lib/shared/widgets/ localization/ theme/
test/unit/ test/contract/ test/integration/ test/fixtures/
```

هذه بنية إرشادية؛ فصل المسؤوليات هو الإلزامي. لا يسمح بدمج domain logic في UI.

## 4. مصدر الحقيقة والتخزين

- الدروس والسيناريوهات والحزم: Pack registry + files + SQLite metadata.
- التقدم والرسوم والصفقات والأحداث: SQLite محلي.
- الإعدادات البسيطة: preferences؛ لا تستخدمها كسجل كبير.
- لا تعتمد قراءة المحتوى الأساسي على الشبكة.
- أي schema change يحتاج migration مرقمة واختبارات؛ لا تحذف قاعدة البيانات لتجاوز فشل migration.

## 5. سلامة التخزين

- تحديث مركب مثل إغلاق صفقة وتسجيل الحدث وتحديث equity يحفظ بمعاملة ذرية أو event log قابل لإعادة البناء.
- مفاتيح ثابتة وidempotency لمنع التكرار.
- قيود وفهارس على مفاتيح الحزم والشموع.
- backup/restore محلي إن نُفذ يملك manifest وإصدارًا وchecksum وتأكيد استبدال؛ ملف غير صالح لا يفسد الحالة الحالية.
- حذف pack لا يحذف journal references. يمنع حذف pack مستخدم في جلسة مفتوحة.

## 6. سياسة Offline-first

- لا تنتظر الوظائف الأساسية network calls.
- اتصال الإنترنت لا يغير مصدر حقيقة السجلات المحلية.
- لا تسجيل إجباري.
- Rules/Simulator/Coach محلية.
- التحديث قابل للإلغاء والفشل الآمن.
- عند غياب الإنترنت يعرض تاريخ البيانات لا تحذيرًا يحجب الشارت.
- لا وصف للبيانات بأنها لحظية.

## 7. التحديث والتزامن

v1 لا يزامن بيانات المستخدم للسحابة. التحديثات أحادية الاتجاه من قناة النشر إلى الجهاز. لا تعارض دمج لسجل المستخدم. أي مزامنة مستقبلية تتطلب قرارًا جديدًا وتصميم conflict resolution ومراجعة خصوصية.

## 8. دورة حياة Android

- حفظ playhead وحالة الصفقة والجلسة على الأحداث المهمة.
- عند background يوقف replay animation أو يخفضها ويحفظ checkpoint.
- resume لا يعيد تنفيذ الأوامر ولا يبدأ من الصفر.
- تحديثات v1 تتحقق أثناء foreground؛ التنزيل يحترم إعداد المستخدم ولا يعمل في الخلفية دون سياسة صريحة.
- لا عمليات indexing ثقيلة على UI thread.

## 9. الأخطاء

كل use case/repository يرجع Result/Failure code واضحًا. لا تبتلع الاستثناءات بصمت. رسائل UI مفهومة؛ logs لا تتضمن بيانات غير لازمة. فشل Ads/Updater لا يضع التطبيق كله في error state.

## 10. التبعيات والبيئة

راجع نشاط الحزمة وترخيصها وصيانتها وحجمها ودعم Android والبدائل قبل الإضافة. ثبت الإصدارات في lockfile. يثبت إصدار Flutter/Android SDK/JDK/Gradle بعد اختبار البيئة الفعلية في Phase 0؛ لا تستخدم إصدارات عائمة في الإصدار النهائي.

## 11. اختبارات المعمارية

- Simulator لا يستورد Flutter widgets.
- Rule engine يمكن اختباره دون Flutter binding.
- Coach يعمل دون شبكة.
- presentation لا تصل إلى data implementation مباشرة دون repository/use case.
- كل updater قابل للاختبار باستخدام manifest وfixtures ثابتة.
- لا أسرار في assets أو Git.
